self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7390bb699949945ef962c3b65274e397",
    "url": "/index.html"
  },
  {
    "revision": "85d7738e113b44f522b1",
    "url": "/static/css/main.4acb5bcd.chunk.css"
  },
  {
    "revision": "355c46b56a3516087245",
    "url": "/static/js/2.2f416465.chunk.js"
  },
  {
    "revision": "c50c771658c38c7c1fcfc5b118622f46",
    "url": "/static/js/2.2f416465.chunk.js.LICENSE.txt"
  },
  {
    "revision": "85d7738e113b44f522b1",
    "url": "/static/js/main.a170f2b1.chunk.js"
  },
  {
    "revision": "f7b5978558fc7dbf75c4",
    "url": "/static/js/runtime-main.83c2aad1.js"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/static/media/logo.5d5d9eef.svg"
  }
]);